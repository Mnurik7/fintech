
  # FinAI Shield App

  This is a code bundle for FinAI Shield App. The original project is available at https://www.figma.com/design/MAq9I9CTsbLe0svv4Nez7R/FinAI-Shield-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  